/*
  Connection ready handler
 */

// Import winston for logging
const winston = require('winston');

module.exports = () => winston.info('Connected to Discord!');
